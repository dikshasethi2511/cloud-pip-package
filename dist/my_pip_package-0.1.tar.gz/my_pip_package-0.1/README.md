# cloud-pip-package

pip install git+https://github.com/dikshasethi2511/cloud-pip-package.git#egg=my_pip_package
